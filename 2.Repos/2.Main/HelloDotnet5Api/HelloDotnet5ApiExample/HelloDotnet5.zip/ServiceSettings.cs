namespace HelloDotnet5
{
    public class ServiceSettings
    {
        public string OpenWeatherHost { get; set; }

        public string ApiKey { get; set; }
    }
}